#include "mbed.h"
//code file for semester one deadline - directional movement and turns by means of motor control.


PwmOut PWM_L(PTA5); //PWM for Left side motors
DigitalOut FRWD_L(PTC6); 
DigitalOut RVRS_L(PTC5); 

PwmOut PWM_R(PTA4); //PWM for Right side motors
DigitalOut FRWD_R(PTC4); 
DigitalOut RVRS_R(PTC3); 


// Dutycyle is a float variable that can change the duty cycle from 0 to 100% (0 to 1) 
// Direction is a boolean variable that chagnes the direction, 1 for forward, 0 for reverse
// MOTOR MUST BE STOPPED BEFORE REVERSING

void motorControl_L(float dutycycle, bool direction) {
    PWM_L = dutycycle;
    if (direction == 1) {
        FRWD_L = 1;
        RVRS_L = 0;
    }
    else{
        FRWD_L = 0;
        RVRS_L = 1;
    }
}

void motorControl_R(float dutycycle, bool direction) {
    PWM_R = dutycycle;
    if (direction == 1) {
        FRWD_R = 1;
        RVRS_R = 0;
    }
    else{
        FRWD_R = 0;
        RVRS_R = 1;
    }
}

int main() {

	//The code loops endlessly, changing direction of travel and PWM output
    while(true){
        
        motorControl_R(1, 1);
        motorControl_L(1, 1);
        wait(1);
    
        motorControl_R(0.5, 1);
        motorControl_L(0.5, 1);
        wait(1);
        
        motorControl_R(0, 1);
        motorControl_L(0, 1);
        wait(1);
        
        
        motorControl_R(0.5, 0);
        motorControl_L(0.5, 0);
        wait(1);
    
        motorControl_R(1, 0);
        motorControl_L(1, 0);
        wait(1);
        
        motorControl_R(0.5, 0);
        motorControl_L(0.5, 0);
        wait(1);
    
        motorControl_R(0, 0);
        motorControl_L(0, 0);
        wait(1);
        
        
    }
}
